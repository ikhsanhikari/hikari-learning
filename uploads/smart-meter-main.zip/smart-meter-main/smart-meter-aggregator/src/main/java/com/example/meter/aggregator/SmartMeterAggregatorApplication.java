package com.example.meter.aggregator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartMeterAggregatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartMeterAggregatorApplication.class, args);
	}

}
