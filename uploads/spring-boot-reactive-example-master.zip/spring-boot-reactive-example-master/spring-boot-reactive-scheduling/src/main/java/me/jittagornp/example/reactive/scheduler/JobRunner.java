/*
 * Copyright 2019-Current jittagornp.me
 */
package me.jittagornp.example.reactive.scheduler;

/**
 * @author jitta
 */
public interface JobRunner {

    void run();

}
