package me.jittagornp.example.reactive.exception;

public class InvalidUsernamePasswordException extends RuntimeException {

}
