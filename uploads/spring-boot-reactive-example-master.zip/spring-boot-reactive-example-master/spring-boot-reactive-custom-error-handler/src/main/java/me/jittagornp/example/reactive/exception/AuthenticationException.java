package me.jittagornp.example.reactive.exception;

public class AuthenticationException extends RuntimeException {

}
