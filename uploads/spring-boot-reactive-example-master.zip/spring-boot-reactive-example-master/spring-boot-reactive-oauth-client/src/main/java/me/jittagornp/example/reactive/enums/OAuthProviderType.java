/*
 * Copyright 2019-Current jittagornp.me
 */
package me.jittagornp.example.reactive.enums;

/**
 * @author jitta
 */
public enum OAuthProviderType {

    GOOGLE,
    FACEBOOK,
    LINE

}
