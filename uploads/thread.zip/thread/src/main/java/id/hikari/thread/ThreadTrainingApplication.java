package id.hikari.thread;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThreadTrainingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThreadTrainingApplication.class, args);
	}

}
