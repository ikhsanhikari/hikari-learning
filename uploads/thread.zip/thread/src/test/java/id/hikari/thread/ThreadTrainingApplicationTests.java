package id.hikari.thread;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreadTrainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
