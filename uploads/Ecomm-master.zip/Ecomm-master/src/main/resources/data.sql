insert into Product_Summary(id, description, price, stock) values('1', 'Women Shoes', '50.3', 100);
insert into Product_Summary(id, description, price, stock) values('2', 'Sports Wears', '180.5', 100);
